from ._embcontent import EmbeddedContent
