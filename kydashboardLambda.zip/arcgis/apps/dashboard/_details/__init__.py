from ._details import Details
