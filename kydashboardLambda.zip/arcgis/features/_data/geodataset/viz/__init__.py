"""
Graphing Library
"""
from arcgis.features._data.geodataset.viz.mapping import plot

__all__ = ["plot"]
